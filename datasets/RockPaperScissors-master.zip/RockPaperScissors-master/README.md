# RockPaperScissors
Membuat sebuah image Classifier untuk klasifikasi gambar rock, scissors, dan paper dengan mengggunakan tensorflow

# Inspiration
Repositori ini saya buat setelah saya menyelesaikan course di [Dicoding](dicoding.com)
